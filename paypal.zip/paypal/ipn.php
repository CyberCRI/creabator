<?php
   // read the post from PayPal system and add 'cmd'   
        $req = 'cmd=_notify-validate';   
           
        foreach ($_POST as $key => $value) {   
        $value = urlencode(stripslashes($value));   
        $req .= "&$key=$value";   
        }   
           
        // post back to PayPal system to validate   
        $header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";   
        $header .= "Content-Type: application/x-www-form-urlencoded\r\n";   
        $header .= "Content-Length: " . strlen($req) . "\r\n\r\n";   
           
        $fp = fsockopen ('ssl://www.sandbox.paypal.com', 443, $errno, $errstr, 30); // ɳ����   
        //$fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30); // ��ʽ��   
           
        // assign posted variables to local variables   
        $item_name = $_POST['item_name1'];   
        $item_number = $_POST['item_number1'];   
        $payment_status = $_POST['payment_status'];   
        $payment_amount = $_POST['mc_gross'];   
        $payment_currency = $_POST['mc_currency'];   
        $txn_id = $_POST['txn_id'];   
        $receiver_email = $_POST['receiver_email'];   
        $payer_email = $_POST['payer_email'];   
        $mc_gross = $_POST['mc_gross'];
        $custom = $_POST['custom'];
       
$root=dirname(dirname(__FILE__));
require_once("$root/engine/start.php"); 

if (!$fp) {   
        // HTTP ERROR 
       
	
        } else { 		
 fputs ($fp, $header . $req) ;
  
while (!feof($fp)) {   
        $res = fgets ($fp, 1024);   
	
        if (strcmp ($res, "VERIFIED") == 0) {   
        // check the payment_status is Completed   
        // check that txn_id has not been previously processed   
        // check that receiver_email is your Primary PayPal email   
        // check that payment_amount/payment_currency are correct   
        // process payment   

$guid=floor($custom/10000000000);
    $backup=get_entity($guid);
    $backup_amt=$backup->backup_amt;
$reward=$backup->pledge_num;
$itemamt=$backup_amt+$reward;
$bp_guid=$backup->bp_guid;
    $project=get_entity($bp_guid);
    $project->annotate('m_state', $itemamt,2,$backup->guid,'integer');
   add_entity_relationship($backup->owner_guid, 'mbacker', $project);
	
$body = <<<HTML
guid:$guid</br>
Amount:$itemamt</br>
custom:$custom</br>
HTML;
// radom select the admin to send message
$users=elgg_get_entities(array('type'=>'user'));
foreach ($users as $user){
	if ($user->isAdmin()){
		$admin_guids[].=$user->guid;
	}
}
$recipient_guid = $admin_guids[ mt_rand(0, count($admin_guids) - 1) ];
$subject ="ipn-VERIFIED";

if (!$recipient_guid) {
	register_error(elgg_echo("messages:user:blank"));
	forward(REFERER);
}

// Make sure the message field, send to field and title are not blank
if (!$body ) {
	register_error(elgg_echo("messages:blank"));
	forward(REFERER);
}

// Otherwise, 'send' the message 
$result = messages_send($subject, $body, $recipient_guid, 0, $reply);

// Save 'send' the message
if (!$result) {
	register_error(elgg_echo("messages:error"));
	forward(REFERER);
}

	
        }   
        else if (strcmp ($res, "INVALID") == 0) {   
        // log for manual investigation   
      
  
        }  
		
        }  
		
        fclose ($fp); 
}
?>   
